'use strict';
/*
 * TECHVENTURE Live Quiz — server
 * Zero dependencies. Requires Node.js 18 or newer.  Run:  node server.js
 *
 * Security model (short version)
 *  - Passwords are stored only as scrypt hashes (per-user salt). Team passwords are random
 *    and shown to the admin exactly once.
 *  - Sessions are HMAC-signed tokens in HttpOnly + SameSite=Strict cookies.
 *  - One live session per team: logging in again signs the old device out.
 *  - Login attempts are rate-limited per username and per IP.
 *  - All timing and scoring happens on the server clock. Clients only display.
 *  - Correct answers are never sent to teams until the question has ended.
 *  - Strict CSP, no inline scripts, same-origin checks on every POST, request size limits.
 */
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { promisify } = require('node:util');
const scrypt = promisify(crypto.scrypt);

/* ------------------------------------------------------------------ .env (optional) */
(function loadEnv() {
  try {
    const raw = fs.readFileSync(path.join(__dirname, '.env'), 'utf8');
    for (const line of raw.split(/\r?\n/)) {
      if (line.trim().startsWith('#')) continue;
      const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/);
      if (!m) continue;
      let v = m[2];
      if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) v = v.slice(1, -1);
      if (process.env[m[1]] === undefined) process.env[m[1]] = v;
    }
  } catch { /* no .env file — fine */ }
})();

/* ------------------------------------------------------------------ config */
const PORT = parseInt(process.env.PORT, 10) || 3000;
const HOST = process.env.HOST || '0.0.0.0';
const ADMIN_USER = String(process.env.ADMIN_USER || 'admin').trim().toLowerCase();
const TRUST_PROXY = process.env.TRUST_PROXY === '1';
const DATA_FILE = path.resolve(process.env.DATA_FILE || path.join(__dirname, 'data', 'techventure.json'));
const PUBLIC_DIR = path.join(__dirname, 'public');

const MIN_FRACTION = 0.3; // a correct answer at the very last moment still earns 30% of the question's points
const GRACE_MS = 600;     // network allowance after the timer reaches zero
const MAX_TEAMS = 300;
const MAX_QUESTIONS = 200;
const MAX_SSE = 1500;

/* ------------------------------------------------------------------ small helpers */
const httpErr = (status, message) => Object.assign(new Error(message), { status });
const safeEqual = (a, b) => {
  const A = Buffer.from(String(a)), B = Buffer.from(String(b));
  return A.length === B.length && crypto.timingSafeEqual(A, B);
};
const cleanStr = (s, max) =>
  typeof s === 'string' ? s.replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, max) : '';
const clampInt = (v, min, max, dflt) => {
  const n = Math.round(Number(v));
  return Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : dflt;
};

/* ------------------------------------------------------------------ persistence */
const DEFAULTS = () => ({
  secret: crypto.randomBytes(32).toString('hex'),
  admin: null,
  teams: [],
  questions: [],
  settings: { title: 'TECHVENTURE Live Quiz', countdownSec: 10, revealSec: 10, autoAdvance: true },
  game: { phase: 'lobby', q: -1, startedAt: 0, endsAt: 0, answers: {} },
});

function loadDb() {
  const d = DEFAULTS();
  let raw;
  try { raw = fs.readFileSync(DATA_FILE, 'utf8'); } catch (e) {
    if (e.code !== 'ENOENT') console.error('Could not read data file:', e.message);
    return d;
  }
  try {
    const j = JSON.parse(raw);
    return { ...d, ...j, settings: { ...d.settings, ...(j.settings || {}) }, game: { ...d.game, ...(j.game || {}) } };
  } catch {
    const backup = DATA_FILE + '.corrupt-' + Date.now();
    fs.renameSync(DATA_FILE, backup);
    console.error('Data file was unreadable. Moved to', backup, '— starting fresh.');
    return d;
  }
}

let db = loadDb();
let saveTimer = null;
function flush() {
  try {
    fs.mkdirSync(path.dirname(DATA_FILE), { recursive: true });
    const tmp = DATA_FILE + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(db), { mode: 0o600 });
    fs.renameSync(tmp, DATA_FILE);
  } catch (e) { console.error('Save failed:', e.message); }
}
function save() {
  if (saveTimer) return;
  saveTimer = setTimeout(() => { saveTimer = null; flush(); }, 250);
}

/* ------------------------------------------------------------------ passwords & tokens */
async function hashPassword(pw, saltHex) {
  const salt = saltHex ? Buffer.from(saltHex, 'hex') : crypto.randomBytes(16);
  const h = await scrypt(pw, salt, 32, { N: 16384, r: 8, p: 1 });
  return { salt: salt.toString('hex'), hash: h.toString('hex') };
}
async function checkPassword(pw, rec) {
  const { hash } = await hashPassword(pw, rec.salt);
  return safeEqual(hash, rec.hash);
}
const PW_ALPHABET = 'ABCDEFGHJKMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789'; // no look-alike characters
function randomPassword(len = 10) {
  let s = '';
  for (let i = 0; i < len; i++) s += PW_ALPHABET[crypto.randomInt(PW_ALPHABET.length)];
  return s;
}

const hmac = (body) => crypto.createHmac('sha256', db.secret).update(body).digest('base64url');
function signToken(payload) {
  const body = Buffer.from(JSON.stringify(payload)).toString('base64url');
  return body + '.' + hmac(body);
}
function verifyToken(tok) {
  if (typeof tok !== 'string') return null;
  const i = tok.indexOf('.');
  if (i < 1) return null;
  const body = tok.slice(0, i), sig = tok.slice(i + 1);
  if (!safeEqual(sig, hmac(body))) return null;
  try {
    const p = JSON.parse(Buffer.from(body, 'base64url').toString('utf8'));
    return p && p.exp > Date.now() ? p : null;
  } catch { return null; }
}

let adminCred = null; // { salt, hash } — from ADMIN_PASSWORD env var, or generated on first run
let dummyCred = null; // used to keep login timing similar for unknown usernames

/* ------------------------------------------------------------------ login rate limiting */
const attempts = new Map();
const isLimited = (key, max) => { const a = attempts.get(key); return !!a && a.n >= max && Date.now() < a.reset; };
const recordFail = (key, windowMs) => {
  const now = Date.now();
  let a = attempts.get(key);
  if (!a || now > a.reset) a = { n: 0, reset: now + windowMs };
  a.n++;
  attempts.set(key, a);
};
setInterval(() => { const now = Date.now(); for (const [k, a] of attempts) if (now > a.reset) attempts.delete(k); }, 60_000).unref();

/* ------------------------------------------------------------------ HTTP plumbing */
const SEC_HEADERS = {
  'Content-Security-Policy':
    "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; " +
    "font-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'",
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'DENY',
  'Referrer-Policy': 'no-referrer',
  'Permissions-Policy': 'camera=(), microphone=(), geolocation=()',
  'Cross-Origin-Opener-Policy': 'same-origin',
  'Cross-Origin-Resource-Policy': 'same-origin',
};
const isHttps = (req) => process.env.FORCE_HTTPS === '1' || req.headers['x-forwarded-proto'] === 'https' || !!req.socket.encrypted;
const secHeaders = (req) => (isHttps(req) ? { ...SEC_HEADERS, 'Strict-Transport-Security': 'max-age=15552000' } : SEC_HEADERS);
const clientIp = (req) => (TRUST_PROXY && req.headers['x-forwarded-for'])
  ? String(req.headers['x-forwarded-for']).split(',')[0].trim()
  : req.socket.remoteAddress || 'unknown';

function sendJson(req, res, status, body, extra = {}) {
  const data = JSON.stringify(body);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'Content-Length': Buffer.byteLength(data),
    ...secHeaders(req),
    ...extra,
  });
  res.end(data);
}

function readJson(req, limit = 64 * 1024) {
  return new Promise((resolve, reject) => {
    if (!String(req.headers['content-type'] || '').startsWith('application/json')) return reject(httpErr(415, 'JSON required'));
    let size = 0, tooBig = false;
    const chunks = [];
    req.on('data', (c) => {
      size += c.length;
      if (size > limit) { tooBig = true; chunks.length = 0; return; }
      if (!tooBig) chunks.push(c);
    });
    req.on('end', () => {
      if (tooBig) return reject(httpErr(413, 'Request too large'));
      try {
        const o = JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}');
        if (o === null || typeof o !== 'object' || Array.isArray(o)) throw new Error('shape');
        resolve(o);
      } catch { reject(httpErr(400, 'Invalid JSON')); }
    });
    req.on('error', reject);
  });
}

function parseCookies(header) {
  const out = {};
  if (!header) return out;
  for (const part of header.split(';')) {
    const i = part.indexOf('=');
    if (i < 0) continue;
    try { out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim()); } catch { /* ignore */ }
  }
  return out;
}

const sameOrigin = (req) => {
  const o = req.headers.origin;
  if (!o) return true;
  try { return new URL(o).host === req.headers.host; } catch { return false; }
};

function auth(req) {
  const p = verifyToken(parseCookies(req.headers.cookie).tv_session);
  if (!p) return null;
  if (p.r === 'admin') return { role: 'admin' };
  if (p.r === 'team') {
    const team = db.teams.find((t) => t.id === p.id);
    if (team && team.sv === p.sv) return { role: 'team', team };
  }
  return null;
}

function sessionCookie(req, token, maxAgeSec) {
  return `tv_session=${encodeURIComponent(token)}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${maxAgeSec}` + (isHttps(req) ? '; Secure' : '');
}

/* ------------------------------------------------------------------ static files */
const TYPES = {
  '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8', '.csv': 'text/csv; charset=utf-8', '.svg': 'image/svg+xml',
  '.png': 'image/png', '.ico': 'image/x-icon',
};
const PAGES = { '/': 'index.html', '/admin': 'admin.html', '/board': 'board.html' };

function serveStatic(req, res, pathname) {
  let rel = PAGES[pathname] || pathname.slice(1);
  try { rel = decodeURIComponent(rel); } catch { return notFound(req, res); }
  if (rel.split(/[\\/]/).some((seg) => seg.startsWith('.'))) return notFound(req, res);
  const full = path.resolve(PUBLIC_DIR, rel);
  if (!full.startsWith(PUBLIC_DIR + path.sep)) return notFound(req, res);
  fs.stat(full, (err, st) => {
    if (err || !st.isFile()) return notFound(req, res);
    res.writeHead(200, {
      'Content-Type': TYPES[path.extname(full).toLowerCase()] || 'application/octet-stream',
      'Content-Length': st.size,
      'Cache-Control': 'no-cache',
      ...secHeaders(req),
    });
    if (req.method === 'HEAD') return res.end();
    fs.createReadStream(full).pipe(res);
  });
}
function notFound(req, res) {
  const body = 'Not found';
  res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8', 'Content-Length': body.length, ...secHeaders(req) });
  res.end(body);
}

/* ------------------------------------------------------------------ scoring & ranking */
function pointsFor(q, msTaken) {
  const total = q.time * 1000;
  const left = Math.max(0, total - msTaken);
  return Math.round(q.points * (MIN_FRACTION + (1 - MIN_FRACTION) * (left / total)));
}

function leaderboard() {
  return [...db.teams]
    .sort((a, b) => b.score - a.score || b.correct - a.correct || a.timeMs - b.timeMs || a.name.localeCompare(b.name))
    .map((t, i) => ({ rank: i + 1, id: t.id, name: t.name, score: t.score, correct: t.correct, timeMs: t.timeMs }));
}

/* ------------------------------------------------------------------ game engine */
let phaseTimer = null;

function armTimer() {
  clearTimeout(phaseTimer);
  const g = db.game;
  if (!['countdown', 'question', 'reveal'].includes(g.phase) || !g.endsAt) return;
  phaseTimer = setTimeout(onPhaseEnd, Math.max(0, g.endsAt - Date.now()));
}

function onPhaseEnd() {
  const g = db.game;
  if (g.endsAt && Date.now() < g.endsAt - 5) return armTimer(); // timer fired early — re-arm
  if (g.phase === 'countdown') startQuestion(0);
  else if (g.phase === 'question') startReveal();
  else if (g.phase === 'reveal') advanceAfterReveal();
}

function startCountdown() {
  const now = Date.now();
  db.game = { phase: 'countdown', q: -1, startedAt: now, endsAt: now + db.settings.countdownSec * 1000, answers: {} };
  commit();
}
function startQuestion(i) {
  const q = db.questions[i];
  const now = Date.now();
  db.game = { phase: 'question', q: i, startedAt: now, endsAt: now + q.time * 1000, answers: {} };
  commit();
}
function startReveal() {
  const g = db.game;
  const q = db.questions[g.q];
  // Scores are applied now (not when the answer arrives) so nobody can infer correctness from a score change mid-question.
  for (const [teamId, a] of Object.entries(g.answers)) {
    const t = db.teams.find((x) => x.id === teamId);
    if (!t) continue;
    t.answered++;
    if (a.choice === q.answer) { t.score += a.points; t.correct++; t.timeMs += a.ms; }
  }
  const now = Date.now();
  g.phase = 'reveal';
  g.startedAt = now;
  g.endsAt = db.settings.autoAdvance ? now + db.settings.revealSec * 1000 : 0;
  commit();
}
function advanceAfterReveal() {
  if (db.game.q + 1 < db.questions.length) startQuestion(db.game.q + 1);
  else finishGame();
}
function finishGame() {
  db.game.phase = 'finished';
  db.game.endsAt = 0;
  commit();
}
function resetGame() {
  db.game = { phase: 'lobby', q: -1, startedAt: 0, endsAt: 0, answers: {} };
  for (const t of db.teams) { t.score = 0; t.correct = 0; t.timeMs = 0; t.answered = 0; }
  commit();
}
function commit() { armTimer(); save(); broadcast(); }

/* ------------------------------------------------------------------ live push (Server-Sent Events) */
const clients = new Set();
const onlineIds = () => new Set([...clients].filter((c) => c.teamId).map((c) => c.teamId));

function buildBase() {
  const g = db.game;
  const lb = leaderboard();
  const now = Date.now();
  const base = {
    now,
    phase: g.phase,
    title: db.settings.title,
    startedAt: g.startedAt,
    endsAt: g.endsAt,
    totalQuestions: db.questions.length,
    teamsTotal: db.teams.length,
    teamsOnline: onlineIds().size,
    minFraction: MIN_FRACTION,
  };
  if (g.phase === 'question' || g.phase === 'reveal') {
    const q = db.questions[g.q];
    base.question = { index: g.q, text: q.text, options: q.options, time: q.time, points: q.points };
    base.answeredCount = Object.keys(g.answers).length;
    if (g.phase === 'reveal') {
      base.question.answer = q.answer;
      base.stats = q.options.map(() => 0);
      for (const a of Object.values(g.answers)) if (a.choice < base.stats.length) base.stats[a.choice]++;
    }
  }
  if (g.phase === 'reveal' || g.phase === 'finished') base.leaderboard = lb.slice(0, 50);
  return { base, lb };
}

function viewFor(client, built) {
  const { base, lb } = built;
  const g = db.game;
  if (client.role === 'board') return base;
  if (client.role === 'admin') {
    const online = onlineIds();
    return {
      ...base,
      admin: {
        teams: db.teams.map((t) => ({
          id: t.id, name: t.name, username: t.username, online: online.has(t.id),
          score: t.score, correct: t.correct, answeredNow: !!g.answers[t.id],
        })),
        questions: db.questions,
        settings: db.settings,
        leaderboard: lb,
      },
    };
  }
  const t = db.teams.find((x) => x.id === client.teamId);
  if (!t) return base;
  const row = lb.find((r) => r.id === t.id);
  const ans = g.answers[t.id];
  const me = { id: t.id, name: t.name, rank: row ? row.rank : null, score: t.score, correct: t.correct };
  if (g.phase === 'question') {
    me.answered = !!ans;
    me.choice = ans ? ans.choice : null;
  }
  if (g.phase === 'reveal') {
    const q = db.questions[g.q];
    me.answered = !!ans;
    me.choice = ans ? ans.choice : null;
    me.result = ans
      ? { correct: ans.choice === q.answer, points: ans.choice === q.answer ? ans.points : 0, ms: ans.ms }
      : { correct: false, points: 0, ms: null };
  }
  return { ...base, me };
}

function sseSend(client, event, data) {
  try { client.res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`); } catch { /* socket closing */ }
}
function broadcast(roles) {
  if (!clients.size) return;
  const built = buildBase();
  for (const c of clients) if (!roles || roles.includes(c.role)) sseSend(c, 'state', viewFor(c, built));
}
let bcTimer = null;
function broadcastSoon(roles) { // coalesces bursts (e.g. 100 teams connecting at once)
  if (bcTimer) return;
  bcTimer = setTimeout(() => { bcTimer = null; broadcast(roles); }, 250);
}
function kickTeam(teamId) {
  for (const c of [...clients]) if (c.teamId === teamId) { sseSend(c, 'kicked', {}); c.res.end(); clients.delete(c); }
}
setInterval(() => { for (const c of clients) sseSend(c, 'ping', { now: Date.now() }); }, 10_000).unref();

function openStream(req, res, ctx) {
  if (clients.size >= MAX_SSE) return sendJson(req, res, 503, { error: 'Server is full' });
  res.writeHead(200, {
    'Content-Type': 'text/event-stream; charset=utf-8',
    'Cache-Control': 'no-store',
    Connection: 'keep-alive',
    'X-Accel-Buffering': 'no',
    ...secHeaders(req),
  });
  res.write('retry: 2000\n\n');
  const c = { res, role: ctx.role, teamId: ctx.team ? ctx.team.id : null };
  clients.add(c);
  req.on('close', () => {
    clients.delete(c);
    broadcastSoon(db.game.phase === 'lobby' ? undefined : ['admin', 'board']);
  });
  sseSend(c, 'state', viewFor(c, buildBase()));
  broadcastSoon(db.game.phase === 'lobby' ? undefined : ['admin', 'board']);
}

/* ------------------------------------------------------------------ quiz validation */
function normalizeQuestion(raw) {
  if (!raw || typeof raw !== 'object') throw httpErr(400, 'Invalid question');
  const text = cleanStr(raw.text ?? raw.question, 400);
  if (text.length < 3) throw httpErr(400, 'Question text is too short');
  let options = (Array.isArray(raw.options) ? raw.options : []).map((o) => cleanStr(String(o ?? ''), 150));
  while (options.length && !options[options.length - 1]) options.pop();
  if (options.length < 2 || options.length > 4) throw httpErr(400, `"${text.slice(0, 40)}": provide 2 to 4 options`);
  if (options.some((o) => !o)) throw httpErr(400, `"${text.slice(0, 40)}": an option in the middle is empty`);

  let answer = -1;
  const a = raw.answer;
  if (typeof a === 'number' && Number.isInteger(a)) answer = a - 1;
  else if (typeof a === 'string') {
    const s = a.trim();
    if (/^[A-Da-d]$/.test(s)) answer = s.toUpperCase().charCodeAt(0) - 65;
    else if (/^[1-4]$/.test(s)) answer = Number(s) - 1;
    else answer = options.findIndex((o) => o.toLowerCase() === s.toLowerCase());
  }
  if (answer < 0 || answer >= options.length) throw httpErr(400, `"${text.slice(0, 40)}": the correct answer must be A–D (or 1–4) and match an option`);

  return {
    text, options, answer,
    time: clampInt(raw.time ?? raw.seconds, 5, 300, 20),
    points: clampInt(raw.points, 10, 10000, 1000),
  };
}

function normalizeSettings(raw) {
  return {
    title: cleanStr(raw.title, 40) || db.settings.title,
    countdownSec: clampInt(raw.countdownSec, 3, 300, db.settings.countdownSec),
    revealSec: clampInt(raw.revealSec, 3, 120, db.settings.revealSec),
    autoAdvance: typeof raw.autoAdvance === 'boolean' ? raw.autoAdvance : db.settings.autoAdvance,
  };
}

/* ------------------------------------------------------------------ teams */
function uniqueUsername(name) {
  const base = name.toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 10) || 'team';
  for (;;) {
    const u = base + crypto.randomInt(100, 1000);
    if (!db.teams.some((t) => t.username === u) && u !== ADMIN_USER) return u;
  }
}
async function createTeam(name) {
  const password = randomPassword(10);
  const rec = await hashPassword(password);
  const team = {
    id: crypto.randomBytes(6).toString('hex'), name, username: uniqueUsername(name),
    salt: rec.salt, hash: rec.hash, sv: 0, score: 0, correct: 0, timeMs: 0, answered: 0,
  };
  db.teams.push(team);
  return { team, password };
}

/* ------------------------------------------------------------------ API */
async function handleApi(req, res, url) {
  const route = url.pathname;
  const send = (status, body, extra) => sendJson(req, res, status, body, extra);

  if (req.method === 'GET') {
    if (route === '/api/time') return send(200, { now: Date.now() });
    if (route === '/api/me') {
      const a = auth(req);
      return send(200, a ? { role: a.role, name: a.team ? a.team.name : 'Admin' } : { role: null });
    }
    if (route === '/api/events') {
      if (url.searchParams.get('view') === 'board') return openStream(req, res, { role: 'board' });
      const a = auth(req);
      if (!a) return send(401, { error: 'Please sign in' });
      return openStream(req, res, a);
    }
    throw httpErr(404, 'Not found');
  }

  if (req.method !== 'POST') throw httpErr(405, 'Method not allowed');
  if (!sameOrigin(req)) throw httpErr(403, 'Cross-site request blocked');

  /* ---- login / logout ---- */
  if (route === '/api/login') {
    const body = await readJson(req);
    const username = cleanStr(body.username, 60).toLowerCase();
    const password = typeof body.password === 'string' ? body.password.slice(0, 200) : '';
    if (!username || !password) throw httpErr(400, 'Enter your username and password');

    const ipKey = 'ip:' + clientIp(req), userKey = 'u:' + username;
    if (isLimited(ipKey, 80) || isLimited(userKey, 6)) throw httpErr(429, 'Too many attempts. Wait a few minutes and try again.');

    let ok = false, team = null, isAdmin = false;
    if (username === ADMIN_USER) {
      ok = await checkPassword(password, adminCred);
      isAdmin = ok;
    } else {
      team = db.teams.find((t) => t.username === username) || null;
      ok = await checkPassword(password, team || dummyCred) && !!team;
    }
    if (!ok) {
      recordFail(ipKey, 5 * 60_000);
      recordFail(userKey, 5 * 60_000);
      console.log(`[login] failed for "${username}" from ${clientIp(req)}`);
      throw httpErr(401, 'Wrong username or password');
    }
    attempts.delete(userKey);

    if (isAdmin) {
      const token = signToken({ r: 'admin', exp: Date.now() + 8 * 3600_000 });
      return send(200, { role: 'admin' }, { 'Set-Cookie': sessionCookie(req, token, 8 * 3600) });
    }
    team.sv++;          // invalidates any other device signed in as this team
    kickTeam(team.id);
    save();
    const token = signToken({ r: 'team', id: team.id, sv: team.sv, exp: Date.now() + 12 * 3600_000 });
    console.log(`[login] team "${team.name}"`);
    return send(200, { role: 'team', name: team.name }, { 'Set-Cookie': sessionCookie(req, token, 12 * 3600) });
  }
  if (route === '/api/logout') {
    return send(200, { ok: true }, { 'Set-Cookie': sessionCookie(req, '', 0) });
  }

  /* ---- team: submit answer ---- */
  if (route === '/api/answer') {
    const a = auth(req);
    if (!a || a.role !== 'team') throw httpErr(401, 'Please sign in');
    const body = await readJson(req);
    const g = db.game;
    const received = Date.now();
    if (g.phase !== 'question' || body.q !== g.q) throw httpErr(409, 'This question is closed');
    if (received > g.endsAt + GRACE_MS) throw httpErr(409, "Time's up");
    const q = db.questions[g.q];
    if (!Number.isInteger(body.choice) || body.choice < 0 || body.choice >= q.options.length) throw httpErr(400, 'Invalid choice');
    if (g.answers[a.team.id]) throw httpErr(409, 'Your team already answered');
    const ms = Math.max(0, received - g.startedAt);
    g.answers[a.team.id] = { choice: body.choice, ms, points: pointsFor(q, ms) };
    save();
    broadcastSoon(['admin', 'board']);
    return send(200, { ok: true }); // deliberately does not say whether it was correct
  }

  /* ---- admin only from here ---- */
  const a = auth(req);
  if (!a || a.role !== 'admin') throw httpErr(401, 'Admin sign-in required');
  const g = db.game;
  const idle = g.phase === 'lobby';

  if (route === '/api/admin/teams') {
    const body = await readJson(req);
    const names = [...new Set((Array.isArray(body.names) ? body.names : []).map((n) => cleanStr(String(n), 40)).filter(Boolean))];
    if (!names.length) throw httpErr(400, 'Enter at least one team name');
    if (names.length > 100) throw httpErr(400, 'Add at most 100 teams at a time');
    if (db.teams.length + names.length > MAX_TEAMS) throw httpErr(400, `Limit is ${MAX_TEAMS} teams`);
    const taken = new Set(db.teams.map((t) => t.name.toLowerCase()));
    const dup = names.find((n) => taken.has(n.toLowerCase()));
    if (dup) throw httpErr(400, `A team named "${dup}" already exists`);
    const created = [];
    for (const name of names) {
      const { team, password } = await createTeam(name);
      created.push({ id: team.id, name: team.name, username: team.username, password });
    }
    save(); broadcast(['admin']);
    return send(200, { created });
  }
  if (route === '/api/admin/teams/reset') {
    const body = await readJson(req);
    const team = db.teams.find((t) => t.id === body.id);
    if (!team) throw httpErr(404, 'Team not found');
    const password = randomPassword(10);
    Object.assign(team, await hashPassword(password));
    team.sv++;
    kickTeam(team.id);
    save(); broadcast(['admin']);
    return send(200, { name: team.name, username: team.username, password });
  }
  if (route === '/api/admin/teams/delete') {
    if (!idle && g.phase !== 'finished') throw httpErr(409, 'Teams can only be removed before or after the quiz');
    const body = await readJson(req);
    const i = db.teams.findIndex((t) => t.id === body.id);
    if (i < 0) throw httpErr(404, 'Team not found');
    kickTeam(db.teams[i].id);
    db.teams.splice(i, 1);
    save(); broadcast();
    return send(200, { ok: true });
  }
  if (route === '/api/admin/quiz') {
    if (!idle) throw httpErr(409, 'Reset the quiz before changing questions');
    const body = await readJson(req, 2 * 1024 * 1024);
    if (!Array.isArray(body.questions) || !body.questions.length) throw httpErr(400, 'No questions found in that file');
    if (body.questions.length > MAX_QUESTIONS) throw httpErr(400, `Limit is ${MAX_QUESTIONS} questions`);
    db.questions = body.questions.map(normalizeQuestion);
    save(); broadcast();
    return send(200, { count: db.questions.length });
  }
  if (route === '/api/admin/quiz/add') {
    if (!idle) throw httpErr(409, 'Reset the quiz before changing questions');
    if (db.questions.length >= MAX_QUESTIONS) throw httpErr(400, `Limit is ${MAX_QUESTIONS} questions`);
    const body = await readJson(req);
    db.questions.push(normalizeQuestion(body.question));
    save(); broadcast();
    return send(200, { count: db.questions.length });
  }
  if (route === '/api/admin/quiz/delete') {
    if (!idle) throw httpErr(409, 'Reset the quiz before changing questions');
    const body = await readJson(req);
    if (!Number.isInteger(body.index) || body.index < 0 || body.index >= db.questions.length) throw httpErr(400, 'Invalid question');
    db.questions.splice(body.index, 1);
    save(); broadcast();
    return send(200, { count: db.questions.length });
  }
  if (route === '/api/admin/settings') {
    db.settings = normalizeSettings(await readJson(req));
    save(); broadcast();
    return send(200, { settings: db.settings });
  }
  if (route.startsWith('/api/admin/game/')) {
    const action = route.slice('/api/admin/game/'.length);
    if (action === 'start') {
      if (!idle) throw httpErr(409, 'The quiz has already started');
      if (!db.questions.length) throw httpErr(400, 'Add questions first');
      if (!db.teams.length) throw httpErr(400, 'Create team logins first');
      startCountdown();
    } else if (action === 'next') {
      if (g.phase === 'countdown') startQuestion(0);
      else if (g.phase === 'question') startReveal();
      else if (g.phase === 'reveal') advanceAfterReveal();
      else throw httpErr(409, 'Nothing to skip right now');
    } else if (action === 'end') {
      if (idle || g.phase === 'finished') throw httpErr(409, 'The quiz is not running');
      if (g.phase === 'question') startReveal();
      finishGame();
    } else if (action === 'reset') {
      resetGame();
    } else throw httpErr(404, 'Unknown action');
    return send(200, { phase: db.game.phase });
  }
  throw httpErr(404, 'Not found');
}

/* ------------------------------------------------------------------ server */
const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://localhost');
    if (url.pathname.startsWith('/api/')) return await handleApi(req, res, url);
    if (req.method !== 'GET' && req.method !== 'HEAD') throw httpErr(405, 'Method not allowed');
    return serveStatic(req, res, url.pathname);
  } catch (e) {
    const status = e.status || 500;
    if (status === 500) console.error(e);
    if (!res.headersSent) {
      if (status === 413) res.once('finish', () => req.destroy());
      sendJson(req, res, status, { error: status === 500 ? 'Server error' : e.message }, status === 413 ? { Connection: 'close' } : {});
    }
  }
});
server.headersTimeout = 15_000;
server.requestTimeout = 30_000;

async function main() {
  dummyCred = await hashPassword(crypto.randomBytes(8).toString('hex'));
  const envPw = process.env.ADMIN_PASSWORD;
  if (envPw) {
    if (envPw.length < 10) console.warn('WARNING: ADMIN_PASSWORD is shorter than 10 characters. Use something stronger.');
    adminCred = await hashPassword(envPw);
  } else if (db.admin) {
    adminCred = db.admin;
    console.log('Admin password: unchanged from first run (set ADMIN_PASSWORD in .env to choose your own).');
  } else {
    const pw = randomPassword(14);
    db.admin = await hashPassword(pw);
    adminCred = db.admin;
    flush();
    console.log('\n  First run — admin login created');
    console.log(`    username: ${ADMIN_USER}`);
    console.log(`    password: ${pw}`);
    console.log('  Save this now. It is stored only as a hash. Set ADMIN_PASSWORD in .env to choose your own.\n');
  }

  armTimer(); // resume timers if the server restarted mid-quiz
  server.listen(PORT, HOST, () => {
    console.log(`TECHVENTURE quiz is live on port ${PORT}`);
    console.log(`  Teams & admin : http://localhost:${PORT}/`);
    console.log(`  Admin console : http://localhost:${PORT}/admin`);
    console.log(`  Big screen    : http://localhost:${PORT}/board`);
  });
}

function shutdown() { flush(); process.exit(0); }
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
main();
