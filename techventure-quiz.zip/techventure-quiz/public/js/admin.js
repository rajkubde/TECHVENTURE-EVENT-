'use strict';
(function () {
  const { h, clear, api } = TV;
  const app = document.getElementById('app');
  let S = null;                 // latest state
  let settingsFilled = false;
  const PHASES = { lobby: 'Lobby', countdown: 'Starting', question: 'Question live', reveal: 'Showing answer', finished: 'Finished' };

  /* ---------- small UI helpers ---------- */
  const say = (el, text, ok) => { el.textContent = text || ''; el.className = 'msg ' + (text ? (ok ? 'ok' : 'err') : ''); };

  function csvCell(v) {
    let s = String(v);
    if (/^[=+\-@\t\r]/.test(s)) s = "'" + s; // stop spreadsheet formula injection
    return '"' + s.replace(/"/g, '""') + '"';
  }
  function download(filename, text) {
    const url = URL.createObjectURL(new Blob([text], { type: 'text/csv;charset=utf-8' }));
    const a = h('a', { href: url, download: filename });
    document.body.append(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 2000);
  }

  function parseCSV(text) {
    text = text.replace(/^\uFEFF/, '');
    const rows = []; let row = [], cell = '', q = false;
    for (let i = 0; i < text.length; i++) {
      const c = text[i];
      if (q) {
        if (c === '"') { if (text[i + 1] === '"') { cell += '"'; i++; } else q = false; } else cell += c;
      } else if (c === '"') q = true;
      else if (c === ',') { row.push(cell); cell = ''; }
      else if (c === '\n' || c === '\r') {
        if (c === '\r' && text[i + 1] === '\n') i++;
        row.push(cell); cell = ''; rows.push(row); row = [];
      } else cell += c;
    }
    if (cell || row.length) { row.push(cell); rows.push(row); }
    return rows.filter((r) => r.some((x) => x.trim()));
  }
  function questionsFromFile(name, text) {
    if (/\.json$/i.test(name)) {
      const j = JSON.parse(text);
      return Array.isArray(j) ? j : j.questions;
    }
    let rows = parseCSV(text);
    if (rows.length && /^question$/i.test(rows[0][0].trim())) rows = rows.slice(1);
    return rows.map((r) => ({ question: r[0], options: [r[1], r[2], r[3], r[4]], answer: (r[5] || '').trim(), time: r[6] ? Number(r[6]) : undefined, points: r[7] ? Number(r[7]) : undefined }));
  }

  /* ---------- credentials dialog ---------- */
  function showCredentials(rows, title) {
    const dlg = h('dialog', { 'aria-label': title });
    const lines = rows.map((r) => `${r.name}\t${r.username}\t${r.password}`).join('\n');
    const copyMsg = h('span', { class: 'muted' });
    dlg.append(
      h('h2', { text: title }),
      h('p', { class: 'notice', text: 'Copy or download these now. Passwords are stored only as hashes, so they cannot be shown again. A new password can be issued later.' }),
      h('div', { class: 'scroll' }, h('table', null,
        h('thead', null, h('tr', null, h('th', { text: 'Team' }), h('th', { text: 'Username' }), h('th', { text: 'Password' }))),
        h('tbody', null, rows.map((r) => h('tr', null, h('td', { text: r.name }), h('td', { class: 'cred', text: r.username }), h('td', { class: 'cred', text: r.password })))))),
      h('div', { class: 'row', 'data-gap': '1' },
        h('button', { class: 'btn small', type: 'button', text: 'Copy all', onclick: async () => {
          try { await navigator.clipboard.writeText(lines); copyMsg.textContent = 'Copied'; } catch { copyMsg.textContent = 'Copy blocked — use Download'; }
        } }),
        h('button', { class: 'btn small ghost', type: 'button', text: 'Download CSV', onclick: () =>
          download('techventure-logins.csv', ['Team,Username,Password', ...rows.map((r) => [r.name, r.username, r.password].map(csvCell).join(','))].join('\n')) }),
        h('button', { class: 'btn small ghost', type: 'button', text: 'Close', onclick: () => { dlg.close(); dlg.remove(); } }),
        copyMsg));
    document.body.append(dlg);
    dlg.showModal();
  }

  /* ---------- panels (built once so typing is never interrupted by live updates) ---------- */
  const ctlBox = h('div', { class: 'stack' }), lbBox = h('div'), teamTable = h('div'), qList = h('div'), qNotice = h('p', { class: 'notice hidden', text: 'Questions are locked while a quiz is in progress. Reset the quiz to edit them.' });

  async function act(name, msgEl) {
    try { await api('/api/admin/game/' + name, {}); say(msgEl, ''); } catch (e) { say(msgEl, e.message); }
  }

  function renderControl(s) {
    const a = s.admin, phase = s.phase;
    const msg = h('p', { class: 'msg', role: 'alert' });
    const clock = h('div', { class: 'stat' }, h('div', null, h('b', { id: 'adm-clock', text: '–' }), h('span', { text: 'timer' })));
    const q = s.question ? a.questions[s.question.index] : null;
    const answered = s.answeredCount || 0;
    const btns = [];
    if (phase === 'lobby') btns.push(h('button', { class: 'btn go', type: 'button', text: 'Start quiz for all teams', onclick: () => {
      if (confirm(`Start now? A ${a.settings.countdownSec}s countdown begins on every team's screen.`)) act('start', msg);
    } }));
    if (['countdown', 'question', 'reveal'].includes(phase)) {
      const label = phase === 'countdown' ? 'Skip countdown' : phase === 'question' ? 'End question now' : (s.question.index + 1 >= s.totalQuestions ? 'Show final results' : 'Next question now');
      btns.push(h('button', { class: 'btn', type: 'button', text: label, onclick: () => act('next', msg) }));
      btns.push(h('button', { class: 'btn warn', type: 'button', text: 'End quiz', onclick: () => { if (confirm('End the quiz now and show final standings?')) act('end', msg); } }));
    }
    if (phase !== 'lobby') btns.push(h('button', { class: 'btn ghost', type: 'button', text: 'Reset scores & return to lobby', onclick: () => { if (confirm('Reset all scores and go back to the lobby?')) act('reset', msg); } }));

    clear(ctlBox).append(
      h('div', { class: 'row' }, h('span', { class: 'badge' + (['countdown', 'question'].includes(phase) ? ' live' : ''), text: PHASES[phase] }),
        s.question ? h('span', { class: 'muted', text: `Question ${s.question.index + 1} of ${s.totalQuestions}` }) : h('span', { class: 'muted', text: `${s.totalQuestions} questions ready` })),
      h('div', { class: 'stat' },
        h('div', null, h('b', { text: `${s.teamsOnline}/${s.teamsTotal}` }), h('span', { text: 'teams online' })),
        phase === 'question' ? h('div', null, h('b', { text: `${answered}/${s.teamsTotal}` }), h('span', { text: 'teams answered' })) : null),
      clock,
      q ? h('p', null, h('span', { class: 'muted', text: 'Now showing: ' }), q.text, h('br'), h('span', { class: 'ok', text: 'Correct: ' + TV.optionLetter(q.answer) + ' — ' + q.options[q.answer] })) : null,
      h('div', { class: 'row' }, btns), msg);

    clear(lbBox).append(h('div', { class: 'scroll' }, h('table', null,
      h('thead', null, h('tr', null, h('th', { text: '#' }), h('th', { text: 'Team' }), h('th', { class: 'num', text: 'Correct' }), h('th', { class: 'num', text: 'Points' }))),
      h('tbody', null, a.leaderboard.map((r) => h('tr', null, h('td', { text: String(r.rank) }), h('td', { text: r.name }), h('td', { class: 'num', text: String(r.correct) }), h('td', { class: 'num', text: r.score.toLocaleString() })))))));
    if (!a.leaderboard.length) clear(lbBox).append(h('p', { class: 'muted', text: 'Create team logins to see the leaderboard.' }));
  }

  function renderTeams(s) {
    const a = s.admin;
    if (!a.teams.length) return clear(teamTable).append(h('p', { class: 'muted', text: 'No teams yet. Add team names above to generate logins.' }));
    const canRemove = s.phase === 'lobby' || s.phase === 'finished';
    clear(teamTable).append(h('div', { class: 'scroll' }, h('table', null,
      h('thead', null, h('tr', null, h('th', { text: 'Team' }), h('th', { text: 'Username' }), h('th', { text: 'Status' }), h('th', { class: 'num', text: 'Points' }), h('th', { text: '' }))),
      h('tbody', null, a.teams.map((t) => h('tr', null,
        h('td', { text: t.name }),
        h('td', { class: 'cred', text: t.username }),
        h('td', null, h('span', { class: 'dot' + (t.online ? ' on' : '') }), ' ', t.online ? 'online' : 'offline'),
        h('td', { class: 'num', text: t.score.toLocaleString() }),
        h('td', { class: 'num' }, h('span', { class: 'row' },
          h('button', { class: 'btn ghost small', type: 'button', text: 'New password', onclick: async () => {
            if (!confirm(`Issue a new password for ${t.name}? Their current session will be signed out.`)) return;
            try { const r = await api('/api/admin/teams/reset', { id: t.id }); showCredentials([r], 'New password'); } catch (e) { alert(e.message); }
          } }),
          h('button', { class: 'btn ghost small', type: 'button', text: 'Remove', disabled: !canRemove, onclick: async () => {
            if (!confirm(`Remove ${t.name}?`)) return;
            try { await api('/api/admin/teams/delete', { id: t.id }); } catch (e) { alert(e.message); }
          } })))))))));
  }

  function renderQuestions(s) {
    const a = s.admin, locked = s.phase !== 'lobby';
    qNotice.classList.toggle('hidden', !locked);
    document.querySelectorAll('[data-lock]').forEach((el) => { el.disabled = locked; });
    if (!a.questions.length) return clear(qList).append(h('p', { class: 'muted', text: 'No questions yet. Upload a file or add one above.' }));
    clear(qList).append(h('ol', { class: 'qlist' }, a.questions.map((q, i) => h('li', null,
      h('span', { class: 'qt', text: `${i + 1}. ${q.text}` }),
      h('span', { class: 'qo' }, q.options.map((o, k) => h('span', { class: k === q.answer ? 'ok' : '' }, `${TV.optionLetter(k)}) ${o}   `))),
      h('span', { class: 'row' },
        h('span', { class: 'muted', text: `${q.time}s · ${q.points} pts` }),
        h('button', { class: 'btn ghost small', type: 'button', text: 'Delete', disabled: locked, onclick: async () => {
          try { await api('/api/admin/quiz/delete', { index: i }); } catch (e) { alert(e.message); }
        } }))))));
  }

  /* ---------- static forms ---------- */
  function teamsForm() {
    const ta = h('textarea', { class: 'input', id: 'names', placeholder: 'One team name per line\nByte Busters\nNull Pointers\nStack Overflowers', 'aria-label': 'Team names' });
    const msg = h('p', { class: 'msg', role: 'alert' });
    return h('div', { class: 'card' },
      h('h2', { text: 'Create team logins' }),
      h('p', { class: 'muted', text: 'Each team gets one username and a random password. Shown once.' }),
      h('div', { class: 'field' }, ta),
      h('button', { class: 'btn', type: 'button', text: 'Create logins', onclick: async (e) => {
        const btn = e.currentTarget; btn.disabled = true; say(msg, '');
        try {
          const names = ta.value.split('\n').map((x) => x.trim()).filter(Boolean);
          const r = await api('/api/admin/teams', { names });
          ta.value = '';
          showCredentials(r.created, `${r.created.length} team login${r.created.length === 1 ? '' : 's'} created`);
        } catch (err) { say(msg, err.message); }
        btn.disabled = false;
      } }), msg);
  }

  function settingsForm() {
    const f = {
      title: h('input', { class: 'input', id: 's-title', maxlength: '40' }),
      cd: h('input', { class: 'input', id: 's-cd', type: 'number', min: '3', max: '300' }),
      rv: h('input', { class: 'input', id: 's-rv', type: 'number', min: '3', max: '120' }),
      auto: h('input', { id: 's-auto', type: 'checkbox' }),
    };
    f.fill = (st) => { f.title.value = st.title; f.cd.value = st.countdownSec; f.rv.value = st.revealSec; f.auto.checked = st.autoAdvance; };
    const msg = h('p', { class: 'msg', role: 'alert' });
    const el = h('div', { class: 'card' },
      h('h2', { text: 'Settings' }),
      h('div', { class: 'settings-grid' },
        h('div', { class: 'field' }, h('label', { for: 's-title', text: 'Event title' }), f.title),
        h('div', { class: 'field' }, h('label', { for: 's-cd', text: 'Start countdown (s)' }), f.cd),
        h('div', { class: 'field' }, h('label', { for: 's-rv', text: 'Answer reveal (s)' }), f.rv)),
      h('label', { class: 'check', for: 's-auto' }, f.auto, 'Move to the next question automatically'),
      h('div', { class: 'row' }, h('button', { class: 'btn', type: 'button', text: 'Save settings', onclick: async () => {
        try {
          await api('/api/admin/settings', { title: f.title.value, countdownSec: Number(f.cd.value), revealSec: Number(f.rv.value), autoAdvance: f.auto.checked });
          say(msg, 'Saved', true);
        } catch (e) { say(msg, e.message); }
      } })), msg);
    return { el, fill: f.fill };
  }

  function quizForms() {
    const fileMsg = h('p', { class: 'msg', role: 'alert' });
    const file = h('input', { type: 'file', id: 'qfile', accept: '.json,.csv,application/json,text/csv', 'data-lock': '1', class: 'input' });
    const upload = h('div', { class: 'card' },
      h('h2', { text: 'Upload a quiz file' }),
      h('p', { class: 'muted' }, 'JSON or CSV. Each question has its own timer and points. Samples: ',
        h('a', { href: '/samples/sample-quiz.json', download: 'sample-quiz.json', text: 'JSON' }), ' · ',
        h('a', { href: '/samples/sample-quiz.csv', download: 'sample-quiz.csv', text: 'CSV' })),
      h('div', { class: 'field' }, h('label', { for: 'qfile', text: 'Choose file' }), file),
      h('button', { class: 'btn', type: 'button', 'data-lock': '1', text: 'Upload and replace quiz', onclick: async () => {
        const f = file.files[0];
        if (!f) return say(fileMsg, 'Choose a .json or .csv file first.');
        if (f.size > 1.5 * 1024 * 1024) return say(fileMsg, 'That file is too large.');
        try {
          const questions = questionsFromFile(f.name, await f.text());
          if (!Array.isArray(questions) || !questions.length) throw new Error('No questions found in that file.');
          if (S && S.admin.questions.length && !confirm(`Replace the ${S.admin.questions.length} current questions with ${questions.length} from this file?`)) return;
          const r = await api('/api/admin/quiz', { questions });
          say(fileMsg, `${r.count} questions loaded.`, true); file.value = '';
        } catch (e) { say(fileMsg, e.message); }
      } }), fileMsg);

    const t = h('input', { class: 'input', id: 'nq-text', maxlength: '400', 'data-lock': '1' });
    const o = [0, 1, 2, 3].map((i) => h('input', { class: 'input', id: 'nq-o' + i, maxlength: '150', 'data-lock': '1', placeholder: `Option ${TV.optionLetter(i)}${i > 1 ? ' (optional)' : ''}` }));
    const ans = h('select', { class: 'input', id: 'nq-ans', 'data-lock': '1' }, [0, 1, 2, 3].map((i) => h('option', { value: TV.optionLetter(i), text: 'Correct: ' + TV.optionLetter(i) })));
    const time = h('input', { class: 'input', id: 'nq-time', type: 'number', min: '5', max: '300', value: '20', 'data-lock': '1' });
    const pts = h('input', { class: 'input', id: 'nq-pts', type: 'number', min: '10', max: '10000', value: '1000', 'data-lock': '1' });
    const addMsg = h('p', { class: 'msg', role: 'alert' });
    const add = h('div', { class: 'card' },
      h('h2', { text: 'Add a question' }),
      h('div', { class: 'field' }, h('label', { for: 'nq-text', text: 'Question' }), t),
      h('div', { class: 'opt-grid' }, o),
      h('div', { class: 'settings-grid' },
        h('div', { class: 'field' }, h('label', { for: 'nq-ans', text: 'Answer' }), ans),
        h('div', { class: 'field' }, h('label', { for: 'nq-time', text: 'Timer (seconds)' }), time),
        h('div', { class: 'field' }, h('label', { for: 'nq-pts', text: 'Max points' }), pts)),
      h('button', { class: 'btn', type: 'button', 'data-lock': '1', text: 'Add question', onclick: async () => {
        try {
          await api('/api/admin/quiz/add', { question: { text: t.value, options: o.map((x) => x.value), answer: ans.value, time: Number(time.value), points: Number(pts.value) } });
          t.value = ''; o.forEach((x) => { x.value = ''; }); say(addMsg, 'Added', true); t.focus();
        } catch (e) { say(addMsg, e.message); }
      } }), addMsg);
    return [upload, add];
  }

  /* ---------- layout ---------- */
  function build() {
    const settings = settingsForm();
    const panels = {
      control: h('div', { class: 'grid2' },
        h('div', { class: 'card' }, h('h2', { text: 'Live control' }), ctlBox),
        h('div', { class: 'card' }, h('h2', { text: 'Leaderboard' }), lbBox),
        settings.el),
      teams: h('div', { class: 'grid2' }, teamsForm(), h('div', { class: 'card' }, h('h2', { text: 'Teams' }), teamTable)),
      quiz: h('div', { class: 'grid2' }, ...quizForms(), h('div', { class: 'card' }, h('h2', { text: 'Questions' }), qNotice, qList)),
    };
    const tabs = h('div', { class: 'tabs', role: 'tablist' });
    const show = (name) => {
      Object.entries(panels).forEach(([k, el]) => el.classList.toggle('hidden', k !== name));
      tabs.querySelectorAll('.tab').forEach((b) => b.setAttribute('aria-selected', String(b.dataset.tab === name)));
    };
    [['control', 'Live control'], ['teams', 'Teams'], ['quiz', 'Quiz']].forEach(([k, label]) =>
      tabs.append(h('button', { class: 'tab', role: 'tab', type: 'button', 'data-tab': k, text: label, onclick: () => show(k) })));
    clear(app).append(h('div', { class: 'admin' },
      h('div', { class: 'admin-top' },
        h('h1', { text: 'TECHVENTURE control room' }),
        h('div', { class: 'row' },
          h('a', { class: 'btn ghost small', href: '/board', target: '_blank', rel: 'noopener', text: 'Open big-screen board' }),
          h('button', { class: 'btn ghost small', type: 'button', onclick: TV.logout, text: 'Sign out' }))),
      tabs, ...Object.values(panels)));
    show('control');
    return settings;
  }

  /* ---------- boot ---------- */
  async function boot() {
    let me = { role: null };
    try { me = await api('/api/me'); } catch { /* offline */ }
    if (me.role !== 'admin') { location.href = '/'; return; }
    const settings = build();
    await TV.syncClock();
    setInterval(TV.syncClock, 90000);
    TV.frameLoop(() => {
      const el = document.getElementById('adm-clock');
      if (!el || !S) return;
      const p = S.phase;
      el.textContent = p === 'countdown' ? `${Math.ceil(TV.secsLeft(S.endsAt))}s to start`
        : p === 'question' ? `${Math.ceil(TV.secsLeft(S.endsAt))}s left`
        : p === 'reveal' ? (S.endsAt ? `Next in ${Math.ceil(TV.secsLeft(S.endsAt))}s` : 'Waiting for you')
        : p === 'finished' ? 'Done' : '–';
    });
    TV.stream('/api/events', {
      state: (s) => {
        S = s;
        if (!s.admin) return;
        if (!settingsFilled) { settings.fill(s.admin.settings); settingsFilled = true; }
        renderControl(s); renderTeams(s); renderQuestions(s);
      },
      unauthorized: () => { location.href = '/'; },
    });
  }
  boot();
})();
