'use strict';
/* Shared client helpers. Nothing here uses innerHTML — all text goes through textContent, so
   team names and question text can never inject markup. */
(function () {
  const TV = (window.TV = {});
  TV.offset = 0;      // serverTime - clientTime, so every device counts down against the server clock
  TV.synced = false;
  TV.now = () => Date.now() + TV.offset;

  /* ---------- DOM ---------- */
  TV.h = function (tag, attrs, ...kids) {
    const el = document.createElement(tag);
    if (attrs) {
      for (const [k, v] of Object.entries(attrs)) {
        if (v == null || v === false) continue;
        if (k === 'class') el.className = v;
        else if (k === 'text') el.textContent = v;
        else if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
        else el.setAttribute(k, v === true ? '' : v);
      }
    }
    for (const kid of kids.flat()) {
      if (kid == null || kid === false) continue;
      el.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
    }
    return el;
  };
  const h = TV.h;
  TV.clear = (el) => { while (el.firstChild) el.removeChild(el.firstChild); return el; };

  /* ---------- network ---------- */
  TV.api = async function (url, body) {
    const opt = body === undefined
      ? { credentials: 'same-origin' }
      : { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) };
    let r;
    try { r = await fetch(url, opt); } catch { throw new Error('Network problem. Check your connection.'); }
    let data = {};
    try { data = await r.json(); } catch { /* empty body */ }
    if (!r.ok) { const e = new Error(data.error || 'Something went wrong'); e.status = r.status; throw e; }
    return data;
  };

  // Take several samples and keep the one with the lowest round-trip time.
  TV.syncClock = async function () {
    let best = null;
    for (let i = 0; i < 6; i++) {
      const t0 = Date.now();
      try {
        const d = await TV.api('/api/time');
        const t1 = Date.now(), rtt = t1 - t0;
        if (!best || rtt < best.rtt) best = { rtt, offset: d.now + rtt / 2 - t1 };
      } catch { /* try again */ }
    }
    if (best) { TV.offset = best.offset; TV.synced = true; }
  };

  // Live updates over Server-Sent Events, with a watchdog that reconnects if the stream goes quiet.
  TV.stream = function (url, on) {
    let es = null, last = Date.now(), closed = false;
    function open() {
      es = new EventSource(url);
      last = Date.now();
      es.addEventListener('state', (e) => {
        last = Date.now();
        const s = JSON.parse(e.data);
        if (!TV.synced) TV.offset = s.now - Date.now();
        on.state(s);
      });
      es.addEventListener('ping', () => { last = Date.now(); });
      es.addEventListener('kicked', () => { closed = true; es.close(); if (on.kicked) on.kicked(); });
      es.onopen = () => { if (on.status) on.status(true); };
      es.onerror = () => {
        if (on.status) on.status(false);
        if (es.readyState === 2 && !closed) { closed = true; if (on.unauthorized) on.unauthorized(); }
      };
    }
    open();
    setInterval(() => {
      if (!closed && Date.now() - last > 25000) { es.close(); open(); }
    }, 8000);
  };

  /* ---------- formatting ---------- */
  TV.secsLeft = (endsAt) => Math.max(0, (endsAt - TV.now()) / 1000);
  TV.fmtSec = (ms) => (ms / 1000).toFixed(1) + 's';
  TV.worthNow = (q, frac, minFraction) => Math.round(q.points * (minFraction + (1 - minFraction) * Math.max(0, Math.min(1, frac))));

  // Run fn every animation frame; returns a stop function. Used for the live countdowns.
  TV.frameLoop = function (fn) {
    let stop = false;
    (function tick() { if (stop) return; fn(); requestAnimationFrame(tick); })();
    return () => { stop = true; };
  };

  /* ---------- ring timer ---------- */
  const NS = 'http://www.w3.org/2000/svg';
  const R = 52, C = 2 * Math.PI * R;
  TV.makeRing = function (xl) {
    const svg = document.createElementNS(NS, 'svg');
    svg.setAttribute('viewBox', '0 0 120 120');
    svg.setAttribute('class', 'ring');
    svg.setAttribute('aria-hidden', 'true');
    const mk = (cls) => {
      const c = document.createElementNS(NS, 'circle');
      c.setAttribute('cx', '60'); c.setAttribute('cy', '60'); c.setAttribute('r', String(R)); c.setAttribute('class', cls);
      return c;
    };
    const fg = mk('ring-fg');
    fg.setAttribute('stroke-dasharray', String(C));
    svg.append(mk('ring-bg'), fg);
    const num = h('strong', { text: '0' });
    const wrap = h('div', { class: 'ring-wrap' + (xl ? ' xl' : ''), role: 'timer', 'aria-label': 'Time left' }, svg,
      h('div', { class: 'ring-label' }, num, h('span', { text: 'seconds' })));
    return {
      el: wrap,
      set(frac, secs) {
        fg.setAttribute('stroke-dashoffset', String(C * (1 - Math.max(0, Math.min(1, frac)))));
        const t = String(Math.ceil(secs));
        if (num.textContent !== t) num.textContent = t;
        wrap.classList.toggle('mid', frac <= 0.5 && frac > 0.25);
        wrap.classList.toggle('low', frac <= 0.25);
      },
    };
  };

  /* ---------- leaderboard / podium ---------- */
  TV.leaderboard = function (rows, opts) {
    opts = opts || {};
    const list = h('ol', { class: 'lb' });
    let shown = rows;
    let extraMe = null;
    if (opts.limit && rows.length > opts.limit) {
      shown = rows.slice(0, opts.limit);
      const me = rows.find((r) => r.id === opts.meId);
      if (me && me.rank > opts.limit) extraMe = me;
    }
    const row = (r, i) => h('li', { class: r.id === opts.meId ? 'me' : '', style: null },
      h('span', { class: 'rk', text: String(r.rank) }),
      h('span', { class: 'nm', text: r.name }),
      h('span', { class: 'sc', text: r.score.toLocaleString() }));
    shown.forEach((r, i) => {
      const li = row(r, i);
      li.style.animationDelay = Math.min(i, 12) * 60 + 'ms';
      list.append(li);
    });
    if (extraMe) {
      list.append(h('li', { class: 'gap', text: '…' }));
      list.append(row(extraMe, 0));
    }
    if (!rows.length) list.append(h('li', { class: 'gap', text: 'No scores yet.' }));
    return list;
  };

  TV.podium = function (rows) {
    const top = rows.slice(0, 3);
    return h('div', { class: 'podium' }, top.map((r, i) =>
      h('div', { class: 'step p' + (i + 1) },
        h('b', { text: ['1st', '2nd', '3rd'][i] }),
        h('span', { class: 'nm', text: r.name }),
        h('span', { class: 'sc', text: r.score.toLocaleString() }))));
  };

  /* ---------- misc ---------- */
  TV.optionLetter = (i) => String.fromCharCode(65 + i);
  TV.logout = async function () { try { await TV.api('/api/logout', {}); } catch { /* ignore */ } location.href = '/'; };
})();
