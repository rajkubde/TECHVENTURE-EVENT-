'use strict';
(function () {
  const { h, clear, api } = TV;
  const app = document.getElementById('app');
  let stopLoop = null;
  let connected = false;
  let teamName = '';

  /* ================================================================ login */
  function showLogin(note, isError) {
    if (stopLoop) stopLoop();
    const user = h('input', { class: 'input', id: 'u', name: 'username', autocomplete: 'username', autocapitalize: 'none', spellcheck: 'false', required: true });
    const pass = h('input', { class: 'input', id: 'p', name: 'password', type: 'password', autocomplete: 'current-password', required: true });
    const msg = h('p', { class: 'msg' + (isError ? ' err' : ''), role: 'alert', text: note || '' });
    const btn = h('button', { class: 'btn', type: 'submit', text: 'Enter the quiz' });

    const form = h('form', {
      class: 'card login-card',
      novalidate: true,
      onsubmit: async (e) => {
        e.preventDefault();
        msg.className = 'msg'; msg.textContent = '';
        btn.disabled = true;
        try {
          const r = await api('/api/login', { username: user.value, password: pass.value });
          if (r.role === 'admin') { location.href = '/admin'; return; }
          startQuiz(r.name);
        } catch (err) {
          msg.className = 'msg err'; msg.textContent = err.message;
          pass.value = '';
          btn.disabled = false;
        }
      },
    },
      h('h2', { text: 'Team login' }),
      h('div', { class: 'field' }, h('label', { for: 'u', text: 'Username' }), user),
      h('div', { class: 'field' }, h('label', { for: 'p', text: 'Password' }), pass),
      btn, msg,
      h('p', { class: 'login-foot' }, 'Your login came from the organisers. One device per team. ',
        h('a', { href: '/board', text: 'Open the big-screen board' })));

    clear(app).append(h('div', { class: 'login-wrap' },
      h('section', null,
        h('h1', { class: 'wordmark', text: 'TECHVENTURE' }),
        h('p', { class: 'tagline', text: 'Live quiz. One clock for every team.' }),
        h('ul', { class: 'rules' },
          h('li', null, h('b', { text: 'Correct' }), h('span', { text: 'The faster you lock it in, the more points you earn.' })),
          h('li', null, h('b', { text: 'Late' }), h('span', { text: 'A correct answer after most of the timer still scores.' })),
          h('li', null, h('b', { text: 'Wrong' }), h('span', { text: 'Zero points.' })))),
      form));
    user.focus();
  }

  /* ================================================================ session */
  async function boot() {
    let me = { role: null };
    try { me = await api('/api/me'); } catch { /* offline */ }
    if (me.role === 'admin') { location.href = '/admin'; return; }
    if (me.role === 'team') startQuiz(me.name); else showLogin();
  }

  let streaming = false;
  async function startQuiz(name) {
    teamName = name;
    if (streaming) return;
    streaming = true;
    clear(app).append(h('div', { class: 'stage' }, h('div', { class: 'center' }, h('p', { class: 'lead', text: 'Syncing clocks…' }))));
    await TV.syncClock();
    setInterval(TV.syncClock, 90000);
    TV.stream('/api/events', {
      state: render,
      status: (ok) => { connected = ok; const d = document.getElementById('conn'); if (d) d.classList.toggle('on', ok); },
      kicked: () => { streaming = false; showLogin('This team signed in on another device, so this one was signed out.', true); },
      unauthorized: () => { streaming = false; showLogin('Your session ended. Sign in again.', true); },
    });
  }

  /* ================================================================ rendering */
  function topbar(s) {
    const me = s.me || {};
    return h('div', { class: 'topbar' },
      h('span', { class: 'chip' }, h('span', { id: 'conn', class: 'dot' + (connected ? ' on' : ''), title: 'Connection' }), me.name || teamName),
      h('span', { class: 'row' },
        h('span', { class: 'chip amber', text: (me.score || 0).toLocaleString() + ' pts' }),
        h('button', { class: 'btn ghost small', type: 'button', onclick: TV.logout, text: 'Sign out' })));
  }
  function shell(s, ...kids) {
    if (stopLoop) { stopLoop(); stopLoop = null; }
    clear(app).append(h('div', { class: 'stage' }, topbar(s), ...kids));
  }

  function render(s) {
    if (!s.me) return;
    if (s.phase === 'lobby') return lobby(s);
    if (s.phase === 'countdown') return countdown(s);
    if (s.phase === 'question') return question(s);
    if (s.phase === 'reveal') return reveal(s);
    if (s.phase === 'finished') return finished(s);
  }

  function lobby(s) {
    shell(s, h('div', { class: 'center' },
      h('h1', { class: 'big-title', text: "You're in." }),
      h('p', { class: 'lead', text: 'Waiting for the host to start. Every team begins at the same moment.' }),
      h('span', { class: 'chip', text: `${s.teamsOnline} of ${s.teamsTotal} teams online` })));
  }

  function countdown(s) {
    const num = h('div', { class: 'count-num', 'aria-live': 'polite', text: '' });
    shell(s, h('div', { class: 'center' },
      h('p', { class: 'lead', text: 'Get ready. Question 1 goes live for everyone together.' }), num));
    let last = -1;
    stopLoop = TV.frameLoop(() => {
      const n = Math.ceil(TV.secsLeft(s.endsAt));
      if (n !== last) {
        last = n;
        num.textContent = String(Math.max(n, 0));
        num.classList.remove('pulse'); void num.offsetWidth; num.classList.add('pulse');
      }
    });
  }

  function question(s) {
    const q = s.question, me = s.me, totalMs = q.time * 1000;
    let locked = !!me.answered, choice = me.choice;
    const ring = TV.makeRing(false);
    const worth = h('strong', { text: String(q.points) });
    const status = h('p', { class: 'status', 'aria-live': 'polite' });

    const buttons = q.options.map((text, i) =>
      h('button', { class: 'opt', type: 'button', onclick: () => pick(i) },
        h('span', { class: 'letter', text: TV.optionLetter(i) }), h('span', { text })));

    function paint(timeUp) {
      buttons.forEach((b, i) => {
        b.disabled = locked || timeUp;
        b.classList.toggle('picked', choice === i);
        b.classList.toggle('faded', (locked || timeUp) && choice !== i);
      });
    }
    async function pick(i) {
      if (locked) return;
      locked = true; choice = i; paint(false);
      status.className = 'status'; status.textContent = 'Locking in…';
      try {
        await api('/api/answer', { q: q.index, choice: i });
        status.className = 'status locked'; status.textContent = 'Answer locked in. Results appear when the timer ends.';
      } catch (e) {
        if (e.status === 409 && /already/i.test(e.message)) { status.className = 'status locked'; status.textContent = 'Your team already answered.'; return; }
        if (e.status === 409) { status.textContent = e.message; return; }
        locked = false; choice = null; paint(false); status.textContent = e.message;
      }
    }

    shell(s,
      h('div', { class: 'q-head' }, ring.el,
        h('div', { class: 'q-meta' },
          h('span', { class: 'chip', text: `Question ${q.index + 1} of ${s.totalQuestions}` }),
          h('p', { class: 'worth' }, worth, ' pts if you answer now'))),
      h('h2', { class: 'q-text', text: q.text }),
      h('div', { class: 'options' }, buttons),
      status);

    paint(false);
    if (locked) { status.className = 'status locked'; status.textContent = 'Answer locked in. Results appear when the timer ends.'; }

    stopLoop = TV.frameLoop(() => {
      const left = TV.secsLeft(s.endsAt), frac = (left * 1000) / totalMs;
      ring.set(frac, left);
      worth.textContent = String(TV.worthNow(q, frac, s.minFraction));
      if (left <= 0) {
        paint(true);
        if (!locked) status.textContent = "Time's up. No answer from your team.";
      }
    });
  }

  function reveal(s) {
    const q = s.question, me = s.me, r = me.result || { correct: false, points: 0, ms: null };
    const state = r.correct ? 'good' : 'bad';
    const headline = r.correct ? 'Correct' : (me.answered ? 'Not this one' : 'No answer');
    const why = r.correct
      ? `Locked in after ${TV.fmtSec(r.ms)}. Faster answers earn more.`
      : (me.answered ? 'Wrong answers score zero.' : 'Your team did not answer in time.');

    const correct = h('div', { class: 'opt right' },
      h('span', { class: 'letter', text: TV.optionLetter(q.answer) }), h('span', { text: q.options[q.answer] }));
    correct.style.setProperty('--c', 'var(--opt-' + 'abcd'[q.answer] + ')');

    const nextLine = h('p', { class: 'status', 'aria-live': 'off' });
    const rows = s.leaderboard || [];

    shell(s,
      h('div', { class: 'center' },
        h('div', { class: 'result ' + state },
          h('h2', { text: headline }),
          h('div', { class: 'pts', text: '+' + r.points.toLocaleString() }),
          h('p', { class: 'why', text: why })),
        h('div', { class: 'result' }, h('p', { class: 'muted', text: 'Correct answer' }), correct),
        me.rank ? h('span', { class: 'chip', text: `You are #${me.rank} with ${me.score.toLocaleString()} pts` }) : null,
        h('h3', { class: 'panel-title', text: 'Leaderboard' }),
        TV.leaderboard(rows, { meId: me.id, limit: 5 }),
        nextLine));

    stopLoop = TV.frameLoop(() => {
      if (!s.endsAt) { nextLine.textContent = 'Waiting for the host to continue.'; return; }
      const left = Math.ceil(TV.secsLeft(s.endsAt));
      const last = q.index + 1 >= s.totalQuestions;
      nextLine.textContent = last ? `Final results in ${left}s` : `Next question in ${left}s`;
    });
  }

  function finished(s) {
    const me = s.me, rows = s.leaderboard || [];
    shell(s, h('div', { class: 'center' },
      h('h1', { class: 'big-title', text: 'Final standings' }),
      me.rank ? h('p', { class: 'lead', text: `Your team finished #${me.rank} with ${me.score.toLocaleString()} points.` }) : null,
      TV.podium(rows),
      TV.leaderboard(rows, { meId: me.id, limit: 10 })));
  }

  boot();
})();
