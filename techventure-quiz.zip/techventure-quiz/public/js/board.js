'use strict';
(function () {
  const { h, clear } = TV;
  const app = document.getElementById('app');
  let stop = null;

  function frame(s, ...kids) {
    if (stop) { stop(); stop = null; }
    clear(app).append(h('div', { class: 'board' },
      h('div', { class: 'bar' },
        h('span', { class: 'brand', text: s.title }),
        h('span', { class: 'chip', text: `${s.teamsOnline} of ${s.teamsTotal} teams online` })),
      ...kids));
  }

  function render(s) {
    if (s.phase === 'lobby') {
      return frame(s, h('div', { class: 'center' },
        h('h1', { class: 'wordmark', text: s.title }),
        h('p', { class: 'lead', text: 'Sign in on your team device. The quiz starts for every team at the same moment.' })));
    }
    if (s.phase === 'countdown') {
      const num = h('div', { class: 'count-num', text: '' });
      frame(s, h('div', { class: 'center' }, h('p', { class: 'lead', text: 'Get ready' }), num));
      let last = -1;
      stop = TV.frameLoop(() => {
        const n = Math.ceil(TV.secsLeft(s.endsAt));
        if (n !== last) { last = n; num.textContent = String(Math.max(n, 0)); num.classList.remove('pulse'); void num.offsetWidth; num.classList.add('pulse'); }
      });
      return;
    }
    if (s.phase === 'question') {
      const q = s.question, ring = TV.makeRing(true);
      const worth = h('strong', { text: String(q.points) });
      const opts = q.options.map((t, i) => h('div', { class: 'opt' }, h('span', { class: 'letter', text: TV.optionLetter(i) }), h('span', { text: t })));
      const locked = h('span', { class: 'chip', text: '' });
      frame(s,
        h('div', { class: 'q-head' }, ring.el,
          h('div', { class: 'q-meta' },
            h('span', { class: 'chip', text: `Question ${q.index + 1} of ${s.totalQuestions}` }),
            h('p', { class: 'worth' }, worth, ' pts for a fast correct answer'),
            locked)),
        h('h2', { class: 'q-text', text: q.text }),
        h('div', { class: 'options' }, opts));
      stop = TV.frameLoop(() => {
        const left = TV.secsLeft(s.endsAt), frac = (left * 1000) / (q.time * 1000);
        ring.set(frac, left);
        worth.textContent = String(TV.worthNow(q, frac, s.minFraction));
        const t = `${s.answeredCount || 0} of ${s.teamsTotal} teams locked in`;
        if (locked.textContent !== t) locked.textContent = t;
      });
      return;
    }
    if (s.phase === 'reveal') {
      const q = s.question, max = Math.max(1, ...s.stats);
      const opts = q.options.map((t, i) => {
        const el = h('div', { class: 'opt ' + (i === q.answer ? 'right' : 'faded') },
          h('span', { class: 'letter', text: TV.optionLetter(i) }), h('span', { text: t }),
          h('span', { class: 'tag', text: `${s.stats[i]} team${s.stats[i] === 1 ? '' : 's'}` }));
        return el;
      });
      const next = h('p', { class: 'status' });
      frame(s, h('div', { class: 'split' },
        h('div', null,
          h('span', { class: 'chip', text: `Question ${q.index + 1} of ${s.totalQuestions}` }),
          h('h2', { class: 'q-text', text: q.text }),
          h('div', { class: 'options' }, opts), next),
        h('div', null, h('h3', { class: 'panel-title', text: 'Leaderboard' }), TV.leaderboard(s.leaderboard || [], { limit: 8 }))));
      stop = TV.frameLoop(() => {
        if (!s.endsAt) { next.textContent = 'Waiting for the host to continue.'; return; }
        next.textContent = (q.index + 1 >= s.totalQuestions ? 'Final results in ' : 'Next question in ') + Math.ceil(TV.secsLeft(s.endsAt)) + 's';
      });
      return;
    }
    if (s.phase === 'finished') {
      const rows = s.leaderboard || [];
      return frame(s, h('div', { class: 'center' },
        h('h1', { class: 'big-title', text: 'Final standings' }),
        TV.podium(rows),
        TV.leaderboard(rows.slice(3, 10), { })));
    }
  }

  (async function boot() {
    await TV.syncClock();
    setInterval(TV.syncClock, 90000);
    TV.stream('/api/events?view=board', { state: render });
  })();
})();
